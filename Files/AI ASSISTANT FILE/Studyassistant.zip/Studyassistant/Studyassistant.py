import google.generativeai as genai
import tkinter as tk
from tkinter import scrolledtext, filedialog
import pyttsx3
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.units import inch
from reportlab.lib import colors

# ✅ Configure Gemini API
genai.configure(api_key="AIzaSyB-iUzdjTdxTQHQIrXE6OSoP5JJv6eZz58")
model = genai.GenerativeModel('gemini-1.5-flash')
chat = model.start_chat()

# 🗣 Text-to-Speech Engine Setup
engine = pyttsx3.init()

# 🧠 Core Function to generate content from Gemini
def get_response(prompt):
    try:
        response = chat.send_message(prompt)
        return response.text
    except Exception as e:
        return f"Error: {e}"

# ✨ Button Actions
def generate_notes():
    topic = topic_entry.get()
    if topic:
        output_box.delete(1.0, tk.END)
        prompt = f"Write detailed study notes on the topic: {topic}"
        response = get_response(prompt)
        output_box.insert(tk.END, response)

def start_quiz():
    topic = topic_entry.get()
    if topic:
        output_box.delete(1.0, tk.END)
        prompt = f"Create a 20 squiz with questions and answers on: {topic}"
        response = get_response(prompt)
        output_box.insert(tk.END, response)

def generate_mcqs():
    topic = topic_entry.get()
    if topic:
        output_box.delete(1.0, tk.END)
        prompt = f"Generate 20 multiple-choice questions (MCQs) with answers on the topic: {topic}"
        response = get_response(prompt)
        output_box.insert(tk.END, response)

def explain_concept():
    topic = topic_entry.get()
    if topic:
        output_box.delete(1.0, tk.END)
        prompt = f"Explain the topic '{topic}' in simple terms for a student."
        response = get_response(prompt)
        output_box.insert(tk.END, response)

# 📄 Export Output to PDF with Better Formatting
def export_to_pdf():
    content = output_box.get(1.0, tk.END).strip()
    topic = topic_entry.get().strip()
    if not content or not topic:
        return

    file_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Files", "*.pdf")])
    if file_path:
        doc = SimpleDocTemplate(file_path, pagesize=letter,
                                rightMargin=40, leftMargin=40,
                                topMargin=60, bottomMargin=40)

        styles = getSampleStyleSheet()
        story = []

        # Title with the Topic Name
        title = f"<b>{topic}</b>"
        title_para = Paragraph(title, styles["Heading1"])
        story.append(title_para)
        story.append(Spacer(1, 0.5 * inch))  # Space after title

        # Split by paragraphs or lines
        for line in content.split('\n'):
            line = line.strip()
            if not line:
                story.append(Spacer(1, 0.2 * inch))
            else:
                # Bold if line starts with something like "Question", "Answer", etc.
                if line.lower().startswith(("question", "answer", "explanation", "note")):
                    para = Paragraph(f"<b>{line}</b>", styles["BodyText"])
                else:
                    para = Paragraph(line, styles["BodyText"])
                story.append(para)

        doc.build(story)

# 🖼 GUI Setup
root = tk.Tk()
root.title("AI Study Assistant")
root.geometry("750x650")
root.configure(bg="#eef2f3")

# 🔍 Topic Input
tk.Label(root, text="Enter Topic:", bg="#eef2f3", font=("Arial", 12)).pack(pady=5)
topic_entry = tk.Entry(root, width=60, font=("Arial", 12))
topic_entry.pack(pady=5)

# 🧾 Output Display
output_box = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=90, height=20, font=("Arial", 12))
output_box.pack(padx=10, pady=10)

# 🔘 Buttons
button_frame = tk.Frame(root, bg="#eef2f3")
button_frame.pack(pady=10)

tk.Button(button_frame, text="Generate Notes", command=generate_notes, width=18, bg="#4CAF50", fg="white", font=("Arial", 10)).grid(row=0, column=0, padx=10)
tk.Button(button_frame, text="Start Quiz", command=start_quiz, width=18, bg="#2196F3", fg="white", font=("Arial", 10)).grid(row=0, column=1, padx=10)
tk.Button(button_frame, text="Generate MCQs", command=generate_mcqs, width=18, bg="#FF9800", fg="white", font=("Arial", 10)).grid(row=0, column=2, padx=10)
tk.Button(button_frame, text="Explain Concept", command=explain_concept, width=18, bg="#9C27B0", fg="white", font=("Arial", 10)).grid(row=0, column=3, padx=10)
tk.Button(button_frame, text="Export to PDF", command=export_to_pdf, width=18, bg="#607D8B", fg="white", font=("Arial", 10)).grid(row=1, column=1, padx=10, pady=10)

root.mainloop()



# pyinstaller --onefile --windowed --hidden-import=google.generativeai gemini_chatbot.py