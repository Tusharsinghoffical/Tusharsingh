

# pip install -r requirements.txt
# gemini_chatbot.py


import google.generativeai
import google.generativeai as genai
import tkinter as tk
from tkinter import scrolledtext
import requests
from io import BytesIO
from tkinter import PhotoImage  


genai.configure(api_key="AIzaSyB-iUzdjTdxTQHQIrXE6OSoP5JJv6eZz58")
model = genai.GenerativeModel('gemini-2.0-flash-thinking-exp-01-21')
chat = model.start_chat()


def display_and_log(conversation, area="input", is_user=False):
    if area == "input":
        chat_box.config(state=tk.NORMAL)
        message = f"You: {conversation}"
        chat_box.insert(tk.END, f"{message}\n\n")
        chat_box.yview(tk.END)
        chat_box.config(state=tk.DISABLED)
    elif area == "output":
        output_box.config(state=tk.NORMAL)
        message = f"Gemini: {conversation}"
        output_box.insert(tk.END, f"{message}\n\n")
        output_box.yview(tk.END)
        output_box.config(state=tk.DISABLED)
        

def send_message():
    user_input = user_entry.get()
    if user_input.lower() == "exit":
        root.quit()

    response = chat.send_message(user_input)
    display_and_log(user_input, "input", is_user=True)
    display_and_log(response.text, "output")
    
    user_entry.delete(0, tk.END)

root = tk.Tk()
root.title("Chatbot with TTS & Code Execution")
root.geometry("600x600")
root.configure(bg="#f4f4f9")

try:
    logo = PhotoImage(file="img.jpg")  
    root.iconphoto(True, logo)
except Exception as e:
    print(f"Error loading logo: {e}")  

chat_box = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=70, height=15, state=tk.DISABLED, bg="#ffffff", fg="#333333", font=("Arial", 12))
chat_box.pack(padx=20, pady=10)

output_box = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=70, height=5, state=tk.DISABLED, bg="#f1f1f1", fg="#333333", font=("Arial", 12))
output_box.pack(padx=20, pady=10)

user_entry = tk.Entry(root, width=60, font=("Arial", 12), bg="#f1f1f1", fg="#333333")
user_entry.pack(padx=20, pady=10)

send_button = tk.Button(root, text="Send", width=15, command=send_message, font=("Arial", 12), bg="#4CAF50", fg="white")
send_button.pack(padx=20, pady=10)

root.mainloop()







# ✅ Confirm Script Works

# python gemini_chatbot.py
# pip install google-generativeai
# pip show google-generativeai
# pyinstaller --onefile --windowed gemini_chatbot.py
# C:\Users\tusha\OneDrive\Desktop\AI\dist\
# Double-click gemini_chatbot.exe. If it still doesn't launch:
# pyinstaller --onefile --windowed --hidden-import=google.generativeai gemini_chatbot.py
